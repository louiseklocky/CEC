clear all;clc;
%% Hydrothermal Limits (Common for all 3 cases)
% Qmin = [5 6 10 13];         Qmax = [15 15 30 25];
% Lower_Limit = repmat(Qmin,1,24);  
% Upper_Limit = repmat(Qmax,1,24);


